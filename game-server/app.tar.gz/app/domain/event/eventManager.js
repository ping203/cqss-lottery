var pomelo = require('pomelo');

var EventManager = function () {

};

/**
 * Listen event for entity
 */
EventManager.prototype.addEvent = function (entity) {
    switch (entity.type) {
        case this.consts.EntityType.PLAYER :
            this.playerEvent.addEventForPlayer(entity);
            addPlayerSaveEvent(entity);
            break;
        case this.consts.EntityType.LOTTERY :
            this.npcEvent.addEventForNPC(entity);
            break;
        case this.consts.EntityType.ITEM :
            this.betItemEvent.addEventForBetItem(entity);
            addBetItemSaveEvent(entity);
            break;
    }
};

/**
 * Add save event for player
 * @param {Object} player The player to add save event for.
 */
function addPlayerSaveEvent(player) {
    var app = pomelo.app;
    player.on('save', function () {
        app.get('sync').exec('playerSync.updatePlayer', player.id, player.strip());
    });

    // player.bets.on('save', function () {
    //     app.get('sync').exec('betSync.updateBet', player.bets.id, player.bets.getSyncItems());
    // });
    //
    // player.task.on('save', function () {
    //     app.get('sync').exec('taskSync.updateTask', player.task.id, player.task);
    // })
}

function addBetItemSaveEvent(betItem) {
    var app = pomelo.app;
    betItem.on('save', function () {
        app.get('sync').exec('betSync.updateBet', betItem.id, betItem.strip());
    });
}

module.exports = {
    id: "eventManager",
    func: EventManager,
    props: [
        {name: "consts", ref: "consts"},
        {name: "playerEvent", ref: "playerEvent"},
        {name: "npcEvent", ref: "npcEvent"},
        {name: "betItemEvent", ref: "betItemEvent"}
    ]
}

